/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package votingsystem;
import java.util.*;
/**
 *
 * @author Vinit Rao
 */
public class Vote {
    private int candidateId;

    public Vote(int candidateId) {
        this.candidateId = candidateId;
    }

    public int getCandidateId() {
        return candidateId;
    }
}
